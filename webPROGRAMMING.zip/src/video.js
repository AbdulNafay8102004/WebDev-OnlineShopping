import React from 'react';

function VideoPlayer() {
  return (
    <video width="1024" height="720" controls autoPlay>
      { <source src="grocery2.mp4" type="video/mp4"/>
}
    </video>
  );
}

export default VideoPlayer;
