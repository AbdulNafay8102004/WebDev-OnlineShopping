import React from 'react';
import './design.css'; // Import your CSS file
 // Corrected import
import Payment from './components/payment.js';
function App() {
  return (
    <div className='container'>

      <Payment /> {/* Render login component */}
    </div>
  );
}

export default App;
