// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "@firebase/firestore";
const firebaseConfig = {
  apiKey: "AIzaSyBN6DYe5ocVulsPJyBfwRXJT7uRx_apj-Q",
  authDomain: "web1-e3117.firebaseapp.com",
  projectId: "web1-e3117",
  storageBucket: "web1-e3117.appspot.com",
  messagingSenderId: "372936316912",
  appId: "1:372936316912:web:ba2335923b1e1a1b64ef35",
  measurementId: "G-7WVQE32Q5E"
};
// Initialize Firebase
const app = initializeApp(firebaseConfig);

