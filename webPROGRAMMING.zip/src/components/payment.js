import React, { Component } from 'react';
import LogiN from './login';
import Cart from './cart.js';
import Categories from './categories.js';
import Home from './home.js';
import Top from './top.js';
import Pic from './pics/icon.jpeg';
import Pic2 from './pics/order12.jpg';

export default class Payment extends Component {
    constructor(props) {
        super(props);
        this.nameRef = React.createRef();
        this.contactRef = React.createRef();
        this.emailRef = React.createRef();
        this.addressRef = React.createRef();
        this.paymentMethodRef = React.createRef();
    }

    handleSave = (e) => {
        e.preventDefault();
        console.log("Name:", this.nameRef.current.value);
        console.log("Contact:", this.contactRef.current.value);
        console.log("Email:", this.emailRef.current.value);
        console.log("Address:", this.addressRef.current.value);
        console.log("Payment Method:", this.paymentMethodRef.current.value);
    }

    render() {
        return (
            <div className='mt-5 d-flex justify-content-left'>
                <title>SHPR</title>
                <img src={Pic} width="10%" alt="Logo" />
                <br />
                <a href={Home} alt="homepage"><button type="submit">Homepage</button></a>
                <a href={Categories} alt="homepage"><button type="submit">Categories</button></a>
                <a href={Cart} alt="homepage"><button type="submit">Cart</button></a>
                <a href={Top} alt="homepage"><button type="submit">Top Sellers</button></a>
                <a href="payment.html" alt="homepage"><button type="submit">Payment Method</button></a>
                <a href={LogiN} alt="homepage"><button type="submit">Sign Up and Login</button></a>
                <h1>SHPR</h1>
                <img src={Pic2} width="15%" alt="order icon" />
                <br />
                <h2>Order form</h2>
                <p><b>Enter the required information below</b></p>
                <br />
                <form onSubmit={this.handleSave}>
                    <label htmlFor="name">Your Name:</label>
                    <br />
                    <input type="text" placeholder="Enter your name" name="name" ref={this.nameRef} />
                    <br />
                    <label htmlFor="contact">Contact Number:</label>
                    <br />
                    <input type="text" placeholder="Enter your contact number" name="contact" ref={this.contactRef} />
                    <br />
                    <label htmlFor="email">E-mail:</label>
                    <br />
                    <input type="email" placeholder="Enter your email" name="email" ref={this.emailRef} />
                    <br />
                    <label htmlFor="text">Shipping Address:</label>
                    <br />
                    <input type="text" placeholder="Street Address" name="text" ref={this.addressRef} />
                    <input type="text" placeholder="City" name="text" ref={this.addressRef} />
                    <input type="text" placeholder="Region" name="text" ref={this.addressRef} />
                    <input type="text" placeholder="Postal Code" name="text" ref={this.addressRef} />
                    <input type="text" placeholder="Country" name="text" ref={this.addressRef} />
                    <br />
                    <label htmlFor="payment">Payment Method:</label>
                    <br />
                    <input type="text" placeholder="Payment method" name="payment" ref={this.paymentMethodRef} />
                    <br />
                    <button type="submit">Place an Order</button>
                    <button type="button" className="Cancel">Cancel</button>
                </form>
                <br /><br /><br /><br /><br /><br /><br />
                <footer>
                    <code>Copyright (c) SHPR</code>
                    <br />
                    <code>Contact:</code>
                    <br />
                    <code><a href="mailto:i221605@nu.edu.pk">i221605@nu.edu.pk</a></code>
                    <code><a href="mailto:i221579@nu.edu.pk">i221579@nu.edu.pk</a></code>
                    <br />
                </footer>
            </div>
        );
    }
}
