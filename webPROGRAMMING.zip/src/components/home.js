import React, { Component } from 'react';

import video from './video/grocery2.mp4';
import LogiN from './login';
import Cart from './cart.js'
import Categories from './categories.js'
import Payment from './payment.js'
import Top from './top.js'
export default class Home extends Component {
    render() {
        return (
            <div className='mt-5 d-flex justify-content-left'>

                <title>SHPR</title>






               
                <br />
                <a href="homepage.html" alt="homepage"><button type="submit">Homepage</button></a>
                <a href={Categories} alt="homepage"><button type="submit">Categories</button></a>
                <a href={Cart} alt="homepage"><button type="submit">Cart</button></a>
                <a href={Top} alt="homepage"><button type="submit">Top Sellers</button></a>
                <a href={Payment} alt="homepage"><button type="submit">Payment Method</button></a>
                <a href={LogiN} alt="homepage"><button type="submit">Sign Up and Login</button></a>




                <h1>SHPR</h1>
                <video width="1024" height="720" controls autoplay>
                    <source src={video} type="video/mp4" />
                </video>
                <br />
                <h2>Quality Products Provided</h2>
                <h4>Providing the finest quality products over the last 10 years.</h4>




                <br /><br /><br /><br /><br /><br /><br />

                <code>Copyright (c) SHPR</code>
                <br />
                <code>Contact:</code>
                <br />
                <code><a href="mailto:i221605@nu.edu.pk">i221605@nu.edu.pk</a></code>
                <code><a href="mailto:i221579@nu.edu.pk">i221579@nu.edu.pk</a></code>
                <br />




            </div>
        );
    }
}
