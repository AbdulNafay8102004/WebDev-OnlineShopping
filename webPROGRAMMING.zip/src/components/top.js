import React, { Component } from 'react';

import pic1 from './pics/beverages.jpg';
import pic2 from './pics/meat.jpg';
import pic3 from './pics/fruits.jpg';

import LogiN from './login';
import Cart from './cart.js'
import Categories from './categories.js'
import Payment from './payment.js'
import Home from './home.js'

export default class Top extends Component {
    render() {
        return (
            <div className='mt-5 d-flex justify-content-left'>

                <title>SHPR</title>






               
                <a href={Home} alt="homepage"><button type="submit">Homepage</button></a>
                <a href={Categories} alt="homepage"><button type="submit">Categories</button></a>
                <a href={Cart} alt="homepage"><button type="submit">Cart</button></a>
                <a href="toppage.html" alt="homepage"><button type="submit">Top Sellers</button></a>
                <a href={Payment} alt="homepage"><button type="submit">Payment Method</button></a>
                <a href={LogiN} alt="homepage"><button type="submit">Sign Up and Login</button></a>





                <h1>SHPR</h1>


                <h1>Our Top Sellers</h1>
                <h3>Beverages</h3>
                <img src={pic1} width="20%" alt="Beverages" />
                <p>All kinds of beverages are available and as you can see among our top sellers.</p>
                <p>Price: $10</p>
                <button type="submit">Add To Cart</button>

                <h3>Meat</h3>
                <img src={pic2} width="20%" alt="Meat" />
                <p>Fresh and juicy meat available everyday. The best meat available going around in the region.</p>
                <p>Price: $13</p>
                <button type="submit">Add To Cart</button>

                <h3>Fruits</h3>
                <img src={pic3} width="20%" alt="fruits" />
                <p>All variety of fresh fruits available depending on the season.</p>
                <p>Price: $8</p>
                <button type="submit">Add To Cart</button>
                <br />

                <a href={Cart} alt="payment website"><button type="submit">Go To Cart</button></a>




                <br /><br /><br /><br /><br /><br /><br />

                <code>Copyright (c) SHPR</code>
                <br />
                <code>Contact:</code>
                <br />
                <code><a href="mailto:i221605@nu.edu.pk">i221605@nu.edu.pk</a></code>
                <code><a href="mailto:i221579@nu.edu.pk">i221579@nu.edu.pk</a></code>
                <br />




            </div>
        );
    }
}
