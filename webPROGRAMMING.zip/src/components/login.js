import React, { Component } from 'react';
import Pic from './pics/login.ico';
import Home from './home.js';
import Cart from './cart.js';
import Categories from './categories.js';
import Payment from './payment.js';
import Top from './top.js';
import Sign from './signup.js';


export default class Login extends Component {
    constructor(props) {
        super(props);
        this.unameRef = React.createRef();
        this.passwordRef = React.createRef();
    }

    handleSave = async(e) => {
        e.preventDefault();
        console.log("Username:", this.unameRef.current.value);
        console.log("Password:", this.passwordRef.current.value);
    }

    render() {
        return (
            <div className='mt-5 d-flex justify-content-left'>
                <title>LOGIN</title>

                <a href={<Home/>} alt="homepage"><button type="submit">Homepage</button></a>
                <a href={<Categories/>} alt="homepage"><button type="submit">Categories</button></a>
                <a href={<Cart/>} alt="homepage"><button type="submit">Cart</button></a>
                <a href={<Top/>} alt="homepage"><button type="submit">Top Sellers</button></a>
                <a href={<Payment/>} alt="homepage"><button type="submit">Payment Method</button></a>
                <a href="login.html" alt="homepage"><button type="submit">Sign Up and Login</button></a>

                <img src={Pic} alt="Logo" />
                <br />
                <br />

                <form onSubmit={this.handleSave}>
                    <label htmlFor="uname">Username:</label>
                    <input type="text" ref={this.unameRef} />
                    <br />
                    <label htmlFor="password">Password:</label>
                    <input type="password" placeholder="Enter password" name="password" ref={this.passwordRef} required></input>
                    <br /><br />
                    <a href={Home} alt="homepage"><button type="submit">Login</button></a>
                    <button type="button" className="Cancel">Cancel</button>
                    <br />
                    <h4>Still not a user?</h4>
                    <br />
                    <a href={Sign} alt="homepage"><button type="submit">Save</button></a>
                </form>

                <br /><br /><br /><br /><br /><br /><br />
                <footer>
                    <code>Copyright (c) SHPR</code>
                    <br />
                    <code>Contact:</code>
                    <br />
                    <code><a href="mailto:i221605@nu.edu.pk">i221605@nu.edu.pk</a></code>
                    <code><a href="mailto:i221579@nu.edu.pk">i221579@nu.edu.pk</a></code>
                    <br />
                </footer>
            </div>
        );
    }
}
