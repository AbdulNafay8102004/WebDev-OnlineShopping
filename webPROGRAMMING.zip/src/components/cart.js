import React, { Component } from 'react';

import pic1 from './pics/beverages.jpg';
import pic2 from './pics/meat.jpg';
import pic3 from './pics/fruits.jpg';
import pic4 from './pics/frozenfood.jpg';
import pic5 from './pics/vegetables.jpg';
import LogiN from './login.js';
import Home from './home.js'
import Categories from './categories.js'
import Payment from './payment.js'
import Top from './top.js'

export default class Cart extends Component {
    render() {
        return (
            <div className='mt-5 d-flex justify-content-left'>

                <title>SHPR</title>







                <a href={Home} alt="homepage"><button type="submit">Homepage</button></a>
                <a href={Categories} alt="homepage"><button type="submit">Categories</button></a>
                <a href="cart.html" alt="homepage"><button type="submit">Cart</button></a>
                <a href={Top} alt="homepage"><button type="submit">Top Sellers</button></a>
                <a href={Payment} alt="homepage"><button type="submit">Payment Method</button></a>
                <a href={LogiN} alt="homepage"><button type="submit">Sign Up and Login</button></a>




                <h1>SHPR</h1>



                <h1>Cart</h1>
                <h3>Items:</h3>
                <img src={pic5} align="center" width="20%" alt="brocolli" />
                <img src={pic2} align="center" width="20%" alt="meat" />
                <img src={pic1} align="center" width="20%" alt="beverages" />
                <img src={pic4} align="center" width="15%" alt="frozen goods" />
                <img src={pic3} align="center" width="20%" alt="fruits" />
                <br /><br />
                <h4>Brocolli: $7</h4>
                <h4>Meat: $13</h4>
                <h4>Beverages: $10</h4>
                <h4>Frozen Food: $11</h4>
                <h4>Fruits: $9</h4>
                <h4>Subtotal: $50</h4>
                <h4>Shipping: $10</h4>
                <h4>TOTAL: $60</h4>
                <a href="payment.html" alt="payment website"><button type="submit">Proceed to payment</button></a>




                <br /><br /><br /><br /><br /><br /><br />
                <footer>
                    <code>Copyright (c) SHPR</code>
                    <br />
                    <code>Contact:</code>
                    <br />
                    <code><a href="mailto:i221605@nu.edu.pk">i221605@nu.edu.pk</a></code>
                    <code><a href="mailto:i221579@nu.edu.pk">i221579@nu.edu.pk</a></code>
                    <br />
                </footer>



            </div>
        );
    }
}
