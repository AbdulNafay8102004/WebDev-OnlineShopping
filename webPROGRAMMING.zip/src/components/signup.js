import React, { Component } from 'react';

import Pic from './pics/login.ico';

import Home from './home.js';
import Cart from './cart.js'
import Categories from './categories.js'
import Payment from './payment.js'
import Top from './top.js'
import Login from './login.js'

export default class Signup extends Component {
    render() {
        return (
            <div className='mt-5 d-flex justify-content-left'>

                <title>Sign-Up</title>







                <a href={Home} alt="homepage"><button type="submit">Homepage</button></a>
                <a href={Categories} alt="homepage"><button type="submit">Categories</button></a>
                <a href={Cart} alt="homepage"><button type="submit">Cart</button></a>
                <a href={Top} alt="homepage"><button type="submit">Top Sellers</button></a>
                <a href={Payment} alt="homepage"><button type="submit">Payment Method</button></a>
                <a href={Login} alt="homepage"><button type="submit">Sign Up and Login</button></a>



                <img src={Pic} alt="Logo" />
                <br />

                <br />

                <br /> <br /> <br />
                <br />
                <h4>Create your new account</h4>
                <br />
                <form>
                    <br /> <br /> <br />
                    <label for="fname">  First Name:</label>
                    <br />
                    <input type="text" placeholder="Enter first name" name="fname" required />
                    <br />
                    <label for="lname">  Last Name:</label>
                    <br />
                    <input type="text" placeholder="Enter first name" name="lname" required />
                    <br />
                    <label for="email"> E-mail:  </label>
                    <br />
                    <input type="email" placeholder="Enter your email" name="email" required />
                    <br />
                    <label for="password">Password :</label>
                    <br />
                    <input type="password" placeholder="Enter password" name="password" required />
                    <br />
                    <label for="password">Confirm Password :</label>
                    <br />
                    <input type="password" placeholder="Enter password again" name="password" required />


                    <br />
                </form>


                <br /><br /><br /><br /><br /><br /><br />

                <footer>
                    <code>Copyright (c) SHPR</code>
                    <br />
                    <code>Contact:</code>
                    <br />
                    <code><a href="mailto:i221605@nu.edu.pk">i221605@nu.edu.pk</a></code>
                    <code><a href="mailto:i221579@nu.edu.pk">i221579@nu.edu.pk</a></code>
                    <br />
                </footer>





            </div>
        );
    }
}
